# MarketGuard AI

MarketGuard AI is a React/Vite prototype for an educational, paper-trading financial decision engine.

## What is included

- User-defined capital and risk budget
- Expected value calculation
- Market-implied probability
- Fractional Kelly calculation
- Volatility input
- Model-agreement and evidence-confidence gates
- Automatic qualification / watch / rejection
- Monte Carlo paper simulation
- Sharpe ratio, Sortino ratio, and maximum drawdown demo calculations
- Built-in market education lessons
- Risk-first design that can explicitly say "REJECTED"
- No brokerage integration and no real-money order execution

## Run locally

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local URL Vite prints.

## Put it on GitHub

Create a new GitHub repository, then:

```bash
git init
git add .
git commit -m "Initial MarketGuard AI prototype"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Important next development stages

1. Replace demo inputs with validated historical market datasets.
2. Build a backtesting engine with out-of-sample testing.
3. Add transaction costs, spreads, slippage, and liquidity constraints.
4. Add model calibration and walk-forward validation.
5. Add authentication and secure user settings.
6. Keep the first public version paper-only.
7. If real-money brokerage execution is ever added, obtain appropriate legal/compliance review and use regulated brokerage infrastructure.

This prototype does not promise profits and should not be treated as financial advice.