import React, { useMemo, useState } from "react";
import {
  ShieldCheck, Brain, GraduationCap, Search, Lock, TrendingUp,
  AlertTriangle, CheckCircle2, XCircle, BookOpen, Calculator,
  ChevronRight, RotateCcw
} from "lucide-react";
import { analyzeSetup, impliedProbability, monteCarlo, sharpeRatio, sortinoRatio, maxDrawdown } from "./engine";

const lessons = [
  { title: "Expected Value", body: "Expected value compares possible outcomes and their probabilities. A positive value does not mean the next outcome will be profitable; it is a long-run statistical concept." },
  { title: "Risk Budget", body: "A risk budget is money you have explicitly designated as risk capital. Essential expenses should not be treated as trading capital." },
  { title: "Volatility", body: "Volatility measures how widely returns vary. Higher volatility can create opportunity, but it also increases uncertainty and potential losses." },
  { title: "Kelly Criterion", body: "Kelly sizing is a mathematical framework for long-run growth when probabilities and payoffs are known. Market estimates are uncertain, so the demo uses fractional Kelly rather than full Kelly." },
  { title: "Drawdown", body: "Drawdown measures the decline from a previous peak. It helps show how painful a losing period could be even when the long-run model looks attractive." }
];

const demoReturns = [0.02,-0.01,0.015,-0.03,0.01,0.018,-0.012,0.009,-0.006,0.014];
const demoEquity = [1000,1020,1010,1025,994,1004,1022,1010,1019,1013,1027];

export function App() {
  const [tab, setTab] = useState("dashboard");
  const [capital, setCapital] = useState(1000);
  const [riskBudget, setRiskBudget] = useState(50);
  const [target, setTarget] = useState(200);
  const [probability, setProbability] = useState(58);
  const [odds, setOdds] = useState(2.0);
  const [maxLoss, setMaxLoss] = useState(35);
  const [volatility, setVolatility] = useState(5);
  const [confidence, setConfidence] = useState(72);
  const [agreement, setAgreement] = useState(76);

  const result = useMemo(() => analyzeSetup({
    probability, decimalOdds: odds, riskBudget, maxLoss, volatility, confidence,
    modelAgreement: agreement
  }), [probability, odds, riskBudget, maxLoss, volatility, confidence, agreement]);

  const simulation = useMemo(() => monteCarlo({
    probability: probability / 100,
    winReturn: Math.max(0, target),
    lossReturn: -Math.max(0, maxLoss),
    bankroll: Number(capital) || 0
  }), [probability, target, maxLoss, capital]);

  const metrics = {
    sharpe: sharpeRatio(demoReturns).toFixed(2),
    sortino: sortinoRatio(demoReturns).toFixed(2),
    drawdown: (maxDrawdown(demoEquity) * 100).toFixed(1),
    implied: (impliedProbability(odds) * 100).toFixed(1)
  };

  const reset = () => {
    setCapital(1000); setRiskBudget(50); setTarget(200); setProbability(58);
    setOdds(2); setMaxLoss(35); setVolatility(5); setConfidence(72); setAgreement(76);
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><ShieldCheck size={22}/></div>
          <div><strong>MarketGuard</strong><span>AI</span><small>Paper Trading Lab</small></div>
        </div>
        <nav>
          {[
            ["dashboard","Dashboard"],["analyze","Analyze"],["learn","Learn"]
          ].map(([id,label]) => (
            <button key={id} className={tab===id ? "nav active" : "nav"} onClick={()=>setTab(id)}>{label}</button>
          ))}
        </nav>
      </header>

      <main>
        {tab === "dashboard" && (
          <>
            <section className="hero">
              <div>
                <p className="eyebrow">FINANCIAL DECISION ENGINE</p>
                <h1>Find opportunities.<br/><em>Protect capital.</em></h1>
                <p className="hero-copy">MarketGuard analyzes a hypothetical setup using probability, expected value, risk, model agreement, and simulations. It can reject an opportunity when the rules are not satisfied.</p>
                <button className="primary" onClick={()=>setTab("analyze")}>Analyze a setup <ChevronRight size={17}/></button>
              </div>
              <div className="hero-card">
                <div className="mini-label">CURRENT ENGINE STATUS</div>
                <div className="status-row"><span className="dot"></span> Analysis engine online</div>
                <div className="rule"></div>
                <div className="mini-grid">
                  <div><b>Risk-first</b><span>Enabled</span></div>
                  <div><b>Paper mode</b><span>Enabled</span></div>
                  <div><b>Auto-deny</b><span>Enabled</span></div>
                  <div><b>Real orders</b><span>Disabled</span></div>
                </div>
              </div>
            </section>

            <section className="three">
              <Feature icon={<Brain/>} title="Explainable AI" text="Every qualification or rejection includes the factors behind the result."/>
              <Feature icon={<Lock/>} title="Risk Gate" text="A setup cannot qualify when its modeled loss exceeds the user's risk budget."/>
              <Feature icon={<GraduationCap/>} title="Learn While You Analyze" text="Turn each market concept into a short interactive lesson."/>
            </section>

            <section className="panel">
              <div className="panel-head"><div><p className="eyebrow">DEMO METRICS</p><h2>Risk analytics</h2></div><span className="pill">Historical demo data</span></div>
              <div className="metric-grid">
                <Metric label="Sharpe ratio" value={metrics.sharpe}/>
                <Metric label="Sortino ratio" value={metrics.sortino}/>
                <Metric label="Max drawdown" value={`${metrics.drawdown}%`}/>
                <Metric label="Market implied probability" value={`${metrics.implied}%`}/>
              </div>
              <p className="disclaimer">These values demonstrate the engine's calculations. They are not a forecast or a recommendation.</p>
            </section>
          </>
        )}

        {tab === "analyze" && (
          <section className="workspace">
            <div className="section-title">
              <div><p className="eyebrow">PAPER ANALYSIS</p><h1>Would this setup qualify?</h1></div>
              <button className="secondary" onClick={reset}><RotateCcw size={16}/> Reset</button>
            </div>

            <div className="workspace-grid">
              <section className="panel inputs">
                <h2>Your constraints</h2>
                <p className="muted">These are hypothetical inputs for the simulator.</p>
                <Field label="Total capital" value={capital} setValue={setCapital} prefix="$"/>
                <Field label="Risk budget" value={riskBudget} setValue={setRiskBudget} prefix="$"/>
                <Field label="Target upside" value={target} setValue={setTarget} prefix="$"/>
                <div className="divider"/>
                <h3>Market assumptions</h3>
                <Field label="Estimated probability" value={probability} setValue={setProbability} suffix="%"/>
                <Field label="Decimal payoff" value={odds} setValue={setOdds} step="0.05"/>
                <Field label="Maximum modeled loss" value={maxLoss} setValue={setMaxLoss} prefix="$"/>
                <Field label="Volatility" value={volatility} setValue={setVolatility} suffix="%"/>
                <Field label="Evidence confidence" value={confidence} setValue={setConfidence} suffix="%"/>
                <Field label="Model agreement" value={agreement} setValue={setAgreement} suffix="%"/>
              </section>

              <section>
                <div className={`decision ${result.label.toLowerCase()}`}>
                  <div className="decision-top">
                    <div><span className="mini-label">ENGINE DECISION</span><h2>{result.label}</h2></div>
                    {result.label === "REJECTED" ? <XCircle size={38}/> : result.label === "QUALIFIED" ? <CheckCircle2 size={38}/> : <AlertTriangle size={38}/>}
                  </div>
                  <div className="score"><div><span>Opportunity score</span><strong>{result.score}/100</strong></div><div className="bar"><i style={{width:`${result.score}%`}}/></div></div>
                  <div className="result-grid">
                    <Metric label="Implied probability" value={`${(result.implied*100).toFixed(1)}%`}/>
                    <Metric label="Expected value" value={`${(result.ev*100).toFixed(1)}%`}/>
                    <Metric label="Fractional Kelly" value={`${(result.kelly*100).toFixed(2)}%`}/>
                  </div>
                </div>

                <div className="panel">
                  <div className="panel-head"><h2>Why the engine decided this</h2><Search size={18}/></div>
                  <ul className="reasons">{result.reasons.map((r,i)=><li key={i}>{r}</li>)}</ul>
                </div>

                <div className="panel">
                  <div className="panel-head"><h2>Monte Carlo paper simulation</h2><Calculator size={18}/></div>
                  <div className="sim-grid">
                    <Metric label="Average modeled outcome" value={`$${simulation.average.toFixed(2)}`}/>
                    <Metric label="5th percentile outcome" value={`$${simulation.worst5.toFixed(2)}`}/>
                    <Metric label="Positive outcome rate" value={`${(simulation.positiveRate*100).toFixed(1)}%`}/>
                  </div>
                  <p className="disclaimer">Simulation uses the probability and payoff assumptions you entered. Random simulation is not evidence that a real market will behave this way.</p>
                </div>
              </section>
            </div>
          </section>
        )}

        {tab === "learn" && (
          <section className="learn">
            <div className="section-title"><div><p className="eyebrow">MARKET ACADEMY</p><h1>Learn what the engine is doing.</h1></div></div>
            <div className="lesson-grid">
              {lessons.map((lesson, i) => (
                <article className="lesson" key={lesson.title}>
                  <div className="lesson-number">0{i+1}</div>
                  <BookOpen size={19}/>
                  <h2>{lesson.title}</h2>
                  <p>{lesson.body}</p>
                  <button onClick={()=>alert("Demo lesson complete. In the full version, this opens an interactive lesson and quiz.")}>Start lesson <ChevronRight size={15}/></button>
                </article>
              ))}
            </div>
            <div className="panel guardrail">
              <AlertTriangle size={22}/>
              <div><h2>Why MarketGuard can say “no”</h2><p>The educational version intentionally separates analysis from real-money execution. A real financial product would require appropriate brokerage integrations, legal/compliance review, disclosures, security controls, and jurisdiction-specific regulatory analysis.</p></div>
            </div>
          </section>
        )}
      </main>

      <footer><span>MarketGuard AI • Prototype</span><span>Paper trading only • No financial advice</span></footer>
    </div>
  );
}

function Feature({icon,title,text}) {
  return <article className="feature"><div className="icon">{icon}</div><h2>{title}</h2><p>{text}</p></article>;
}
function Metric({label,value}) {
  return <div className="metric"><span>{label}</span><strong>{value}</strong></div>;
}
function Field({label,value,setValue,prefix,suffix,step="1"}) {
  return <label className="field"><span>{label}</span><div className="input-wrap">{prefix && <b>{prefix}</b>}<input type="number" min="0" step={step} value={value} onChange={e=>setValue(Number(e.target.value))}/>{suffix && <b>{suffix}</b>}</div></label>;
}