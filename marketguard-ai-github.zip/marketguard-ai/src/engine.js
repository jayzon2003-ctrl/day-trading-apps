// Educational/paper-trading calculations.
// These calculations are not predictions and do not guarantee outcomes.

export const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

export function impliedProbability(decimalOdds) {
  if (!Number.isFinite(decimalOdds) || decimalOdds <= 1) return null;
  return 1 / decimalOdds;
}

export function expectedValue(probability, decimalOdds) {
  if (!Number.isFinite(probability) || !Number.isFinite(decimalOdds)) return null;
  return probability * decimalOdds - 1;
}

export function volatilityFromReturns(returns) {
  if (!returns?.length) return 0;
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + (r - mean) ** 2, 0) / returns.length;
  return Math.sqrt(variance);
}

export function maxDrawdown(equity) {
  if (!equity?.length) return 0;
  let peak = equity[0], worst = 0;
  for (const value of equity) {
    peak = Math.max(peak, value);
    if (peak > 0) worst = Math.max(worst, (peak - value) / peak);
  }
  return worst;
}

export function sharpeRatio(returns, riskFree = 0) {
  const vol = volatilityFromReturns(returns);
  if (!vol) return 0;
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  return (mean - riskFree) / vol;
}

export function sortinoRatio(returns, target = 0) {
  const downside = returns.filter(r => r < target).map(r => (r - target) ** 2);
  if (!downside.length) return 0;
  const downsideDev = Math.sqrt(downside.reduce((a,b) => a+b, 0) / downside.length);
  const mean = returns.reduce((a,b) => a+b, 0) / returns.length;
  return downsideDev ? (mean - target) / downsideDev : 0;
}

export function fractionalKelly(probability, decimalOdds, fraction = 0.25) {
  // Kelly for decimal odds: f* = (bp - q) / b
  if (probability <= 0 || probability >= 1 || decimalOdds <= 1) return 0;
  const b = decimalOdds - 1;
  const q = 1 - probability;
  return clamp(((b * probability - q) / b) * fraction, 0, 1);
}

export function monteCarlo({ probability, winReturn, lossReturn, trials = 5000, bankroll = 1000 }) {
  const safeTrials = clamp(Math.floor(trials), 100, 20000);
  const outcomes = [];
  for (let i = 0; i < safeTrials; i++) {
    outcomes.push(Math.random() < probability ? winReturn : lossReturn);
  }
  const avg = outcomes.reduce((a,b) => a+b, 0) / safeTrials;
  const sorted = [...outcomes].sort((a,b) => a-b);
  const p05 = sorted[Math.floor(safeTrials * 0.05)];
  return {
    average: avg,
    worst5: p05,
    positiveRate: outcomes.filter(x => x > 0).length / safeTrials,
    endingCapital: bankroll + avg
  };
}

export function analyzeSetup(input) {
  const p = clamp(Number(input.probability) / 100, 0.001, 0.999);
  const odds = Math.max(1.01, Number(input.decimalOdds) || 1.01);
  const implied = impliedProbability(odds);
  const ev = expectedValue(p, odds);
  const kelly = fractionalKelly(p, odds, 0.25);
  const riskBudget = Math.max(0, Number(input.riskBudget) || 0);
  const maxLoss = Math.max(0, Number(input.maxLoss) || 0);
  const volatility = clamp(Number(input.volatility) || 0, 0, 100);
  const confidence = clamp(Number(input.confidence) || 0, 0, 100);
  const modelAgreement = clamp(Number(input.modelAgreement) || 0, 0, 100);

  const reasons = [];
  let score = 50;

  if (ev > 0) { score += 15; reasons.push("Estimated probability is above the market-implied probability."); }
  else { score -= 25; reasons.push("The estimated probability does not beat the market-implied probability."); }

  if (confidence >= 70) { score += 10; reasons.push("Evidence confidence clears the model threshold."); }
  else if (confidence < 50) { score -= 12; reasons.push("Evidence confidence is too low."); }

  if (modelAgreement >= 70) { score += 8; reasons.push("Independent model signals are broadly aligned."); }
  else if (modelAgreement < 50) { score -= 10; reasons.push("Model disagreement is high."); }

  if (volatility > 8) { score -= 12; reasons.push("Volatility is elevated."); }

  if (maxLoss > riskBudget) {
    score -= 40;
    reasons.push("Maximum modeled loss exceeds the user's risk budget.");
  } else {
    reasons.push("Maximum modeled loss fits within the user's risk budget.");
  }

  score = Math.round(clamp(score, 0, 100));
  const reject =
    maxLoss > riskBudget ||
    ev <= 0 ||
    confidence < 45 ||
    modelAgreement < 45;

  const label = reject ? "REJECTED" : score >= 75 ? "QUALIFIED" : "WATCH";

  return { implied, ev, kelly, score, label, reasons };
}